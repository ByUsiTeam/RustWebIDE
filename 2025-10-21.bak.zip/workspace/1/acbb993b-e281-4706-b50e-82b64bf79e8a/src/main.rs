fn main() {
    println!("Hello, Rust Web IDE!");
}
