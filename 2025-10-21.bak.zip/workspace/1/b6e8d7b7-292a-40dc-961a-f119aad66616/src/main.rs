fn main() {
    println!("Hello, Rust Web IDE!");
    println!("01");
}